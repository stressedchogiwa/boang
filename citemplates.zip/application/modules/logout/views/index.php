<?php
     pre_r($navigation);
?>
