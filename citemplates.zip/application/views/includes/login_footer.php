          </div>
          <script src="<?php echo base_url('static/js/jquery.min.js'); ?>"></script>
          <script src="<?php echo base_url('static/js/bootstrap.min.js'); ?>"></script>
     </body>
</html>
