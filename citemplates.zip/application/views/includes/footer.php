    <?php
        __load_assets__($__assets__,'js');
    ?>
    </body>
</html>
