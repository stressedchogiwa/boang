<Link rel="stylesheet" href="<?php echo base_url('static/css/style.css'); ?>"/>
